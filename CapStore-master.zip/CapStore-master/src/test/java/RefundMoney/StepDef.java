package RefundMoney;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {


	@Given("^Returned Product$")
	public void returned_Product() throws Throwable {


	}

	@When("^Is verified by admin$")
	public void is_verified_by_admin() throws Throwable {


	}

	@Then("^Initiate the refund process$")
	public void initiate_the_refund_process() throws Throwable {


	}

	@When("^Is verified by admin and not permitted to initiate refund$")
	public void is_verified_by_admin_and_not_permitted_to_initiate_refund() throws Throwable {


	}

	@Then("^Cant Initiate the refund process$")
	public void cant_Initiate_the_refund_process() throws Throwable {
	 
	}

}
