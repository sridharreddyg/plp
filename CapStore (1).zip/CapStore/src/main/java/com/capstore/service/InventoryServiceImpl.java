package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.capstore.bean.Inventory;
import com.capstore.bean.Merchant;
import com.capstore.bean.Product;
import com.capstore.repo.InventoryRepo;
import com.capstore.repo.MerchantRepo;
import com.capstore.repo.ProductRepo;

@Service
@Transactional
public class InventoryServiceImpl implements IInventoryService {

	@Autowired
	MerchantRepo merchRepo;

	@Autowired
	InventoryRepo invRepo;

	@Autowired
	ProductRepo prodRepo;

	/**
	 * @author Mayuresh Shinde
	 */
	public Inventory addInventory(Inventory inv, int productId, int merchantId) {
		Product product = prodRepo.findById(productId).get();
		Merchant merchant = merchRepo.findById(merchantId).get();
		inv.setMerchant(merchant);
		inv.setProduct(product);
		return invRepo.save(inv);
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Inventory updateInventory(Inventory inv, int productId, int merchantId) {
		Product product = prodRepo.findById(productId).get();
		Merchant merchant = merchRepo.findById(merchantId).get();
		inv.setMerchant(merchant);
		inv.setProduct(product);
		return invRepo.save(inv);
	}

	/** Returns EmptyResultDataAccessException if inventory not found by given id */
	/**
	 * @author Mayuresh Shinde
	 */
	public String deleteInventory(int invId) {
		try {
			invRepo.deleteById(invId);
			return "Inventory deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Inventory Found To delete", invId);
		}

	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Iterable<Inventory> getAllInventries() {
		return invRepo.findAll();
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Iterable<Inventory> inventriesOfMerchant(int merchantId) {
		Merchant merchant = merchRepo.findById(merchantId).get();
		return merchant.getInventory();
	}
}
