/*
 * CouponServiceImpl
 * 
 * Author : Mayur Hiwarkar
 * 
 * 
 */

package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Coupon;
import com.capstore.repo.CouponRepo;

@Repository
@Transactional
public class CouponServiceImpl implements CouponService {

	@Autowired
	private CouponRepo repo;

	// set Is Used Parameter to Default "No"
	@Override
	public Coupon couponGenerateAndSend(Coupon c) {

		c.setIsUsed("No");

		return repo.save(c);

	}

}