package com.capstore.service;

import java.util.List;

import com.capstore.bean.Review;


public interface IReviewService {

	String addReview(int productId, Review review);

	String updateReview(Review review);

	String deleteReview(int reviewId);

	List<Review> getProductReviewById(int productId);

	Review getReview(int reviewId);

}
