package com.capstore.service;

import com.capstore.bean.Admin;

public interface IAdminService {

	Admin getByEmailAndPass(String email, String password);
}
