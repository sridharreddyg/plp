/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.1
 */
package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import com.capstore.bean.Category;
import com.capstore.bean.Inventory;
import com.capstore.bean.Merchant;
import com.capstore.bean.Product;
import com.capstore.repo.CategoryRepo;
import com.capstore.repo.InventoryRepo;
import com.capstore.repo.MerchantRepo;
import com.capstore.repo.ProductRepo;
import com.capstore.repo.ReviewRepo;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
	@Autowired
	CategoryRepo catRepo;

	@Autowired
	ProductRepo prodRepo;

	@Autowired
	MerchantRepo merchRepo;

	@Autowired
	ReviewRepo reviewRepo;

	/**
	 * @author Mayuresh Shinde
	 */
	public Category addCategory(Category category) {
		return catRepo.save(category);

	}

	public Category getCategory(int id) {
		return catRepo.findById(id).get();
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Category updateCategory(Category category) {
		return catRepo.save(category);
	}

	/** Returns EmptyResultDataAccessException if category not found by given id */
	public String deleteCategory(int catId) {
		try {
			catRepo.deleteById(catId);
			return "Category deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Category Found To delete", catId);
		}
	}

	/**
	 * @author Mayuresh Shinde
	 * @param Product,
	 *            Category id
	 * @return product
	 */
	public Product saveProduct(Product product, int catId) {
		Category cat = catRepo.findById(catId).get();
		product.setCategory(cat);
		return prodRepo.save(product);
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Product updateProduct(Product product, int catId) {
		Category cat = catRepo.findById(catId).get();
		product.setCategory(cat);
		return prodRepo.save(product);
	}

	/** Returns EmptyResultDataAccessException if product not found by given id */
	/**
	 * @author Mayuresh Shinde
	 */
	public String deleteProduct(int productId) {
		try {
			prodRepo.deleteById(productId);
			return "Product deleted";
		} catch (EmptyResultDataAccessException e) {
			throw new EmptyResultDataAccessException("No Product Found To delete", productId);
		}
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Iterable<Category> getAllCategory() {
		return catRepo.findAll();
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public Iterable<Product> getAllProduct() {
		Iterable<Product> prods = prodRepo.findAll();
		for (Product product : prods) {
			System.out.println(product.getCategory());
		}
		return prods;
	}

	/**
	 * @author Mayuresh Shinde
	 */
	public List<Product> getAllProductOfMerchant(int merchantId) {
		Merchant merchant = merchRepo.findById(merchantId).get();
		Iterable<Inventory> inv = merchant.getInventory();
		System.out.println(inv);
		List<Product> products = new ArrayList<Product>();
		for (Inventory inventory : inv) {
			products.add(inventory.getProduct());
		}
		return products;
	}

	/**
	 * @author Mayuresh Shinde
	 * @param id
	 * @return product
	 */
	public Product getProduct(int id) {
		return prodRepo.findById(id).get();
	}

	/**
	 * Author :- Pradnya Gaikwad 173579 version:- 1.0.1
	 */

	// fetch similar product by category name
	public List<Product> findByname(String name) {
		Iterable<Category> category = catRepo.findByname(name);
		List<Product> products = new ArrayList<Product>();
		for (Category cat : category) {
			products.addAll(cat.getProduct());
		}
		return products;
	}

	/**
	 * @author Durvesh
	 */
	@Override
	public Iterable<Product> findByProductName(String productName) {
		return prodRepo.findByProdName(productName);

	}

	@Override
	public Iterable<Product> findByProductBrand(String productBrand) {
		return prodRepo.findByProdBrand(productBrand);
	}
}
