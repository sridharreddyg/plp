package com.capstore.service;

import com.capstore.bean.Cart;

/**
 * Author :- Ajay Amrutkar 173581 version :- 1.0.1
 */

public interface CartService {

	void saveCart(Cart c);

	Iterable<Cart> getAll2();

	Cart getcartById(int id);

	void delete(int id);
}
