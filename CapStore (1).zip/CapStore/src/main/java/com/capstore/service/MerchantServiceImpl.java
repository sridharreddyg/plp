/**
 * @author Varsha Pandita
 */
package com.capstore.service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capstore.bean.Merchant;
import com.capstore.repo.MerchantRepo;

@Service
@Transactional
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantRepo dao;

	@Override
	public void saveMerchant(Merchant merchant) {
		dao.save(merchant);
	}

	@Override
	public Merchant findById(int id) {
		return dao.findById(id).get();
	}

	@Override
	public String deleteMerchant(int id) {
		dao.deleteById(id);
		return "Merchant Deleted Successfully";
	}

	public Iterable<Merchant> getAll() {
		return dao.findAll();
	}

	public Merchant getByEmailAndPass(String email, String password) {
		return dao.findByEmailAndPassword(email, password);
	}

}
