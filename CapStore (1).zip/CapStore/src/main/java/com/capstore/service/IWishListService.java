package com.capstore.service;

import com.capstore.bean.WishList;

public interface IWishListService {

	void saveWishList(WishList wishList);
}
