package com.capstore.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.capstore.bean.MostView;
import com.capstore.bean.Order;
import com.capstore.bean.Product;


public interface ICapStoreAnalysisService {

	public List<Product> getAllProductOfMerchant(int merchantId);
	
	public List<MostView> getAllMostViewed();
	
	public List<Order> getAllOrder();
	
	public Iterable<MostView> viewByProduct();
}
