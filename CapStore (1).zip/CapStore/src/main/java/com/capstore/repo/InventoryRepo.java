package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Inventory;

public interface InventoryRepo extends CrudRepository<Inventory, Integer> {

}
