package com.capstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capstore.bean.DBFile;
import com.capstore.bean.Image;

@Repository
public interface DBFileRepository extends JpaRepository<DBFile, String> {

	public Image save(Image image);
}
