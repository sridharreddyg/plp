package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.MostView;

public interface MostViewRepo extends CrudRepository<MostView, Integer> {

}
