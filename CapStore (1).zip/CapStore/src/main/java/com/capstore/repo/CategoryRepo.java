package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Category;

public interface CategoryRepo extends CrudRepository<Category, Integer> {

	/*
	 * Author :- Pradnya Gaikwad 173579
	 * version:- 1.0.1
	 */	
	public Iterable<Category> findByname(String name);
}
