package com.capstore.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.capstore.bean.DBFile;
import com.capstore.bean.Image;
import com.capstore.bean.Product;
import com.capstore.payload.UploadFileResponse;
import com.capstore.repo.DBFileRepository;
import com.capstore.service.DBFileStorageService;
import com.capstore.service.IProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/image")
public class ImageController {

	/**
	 * Auto Wiring the Storage and repository
	 * 
	 */

	@Autowired
	private DBFileRepository dbFileRepository;

	@Autowired
	private DBFileStorageService DBFileStorageService;

	@Autowired
	private IProductService prodService;

	/**
	 * using post mapping for uploading image
	 * 
	 * @param file
	 * @return Url to view the file
	 * @author yash naik
	 */
	@PostMapping(path = "/uploadFile/{prodId}/{catId}")
	public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file, @PathVariable("prodId") int prodId,
			@PathVariable("catId") int catId) {
		DBFile dbFile = DBFileStorageService.storeFile(file);
		String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/showFile/")
				.path(dbFile.getId()).toUriString();
		System.out.println(dbFile.getId());
		Image image = new Image();
		image.setPath(fileDownloadUri);
		Product product = prodService.getProduct(prodId);
		image.setProductFromImage(product);
		product.addImage(image);
		prodService.updateProduct(product, catId);
		// System.out.println(product.getImageFromProduct());
		return new UploadFileResponse(dbFile.getFileName(), fileDownloadUri, file.getContentType(), file.getSize());

	}

	/**
	 * using post uploadMultipleFiles mapping for uploading multiple images
	 * 
	 * @param files
	 * @return url to view the files
	 * @author yash naik
	 */
	@PostMapping(path = "/uploadMultipleFiles/{prodId}/{catId}")
	public List<UploadFileResponse> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files,
			@PathVariable("prodId") int prodId, @PathVariable("catId") int catId) {
		return Arrays.asList(files).stream().map(file -> uploadFile(file, prodId, catId)).collect(Collectors.toList());
	}

	/**
	 * Get Mapping for viewing the uploaded
	 * 
	 * @param fileId
	 * @return
	 * @author yash naik
	 */
	@GetMapping(path = "/showFile/{fileId}")
	public ResponseEntity<Resource> showFile(@PathVariable String fileId) {
		// Load file from database
		DBFile dbFile = DBFileStorageService.getFile(fileId);

		// try {
		// byte[] byteArray = dbFile.getData();
		// FileOutputStream fout = new FileOutputStream("/Product Images/product.jpeg");
		// fout.write(byteArray);
		// fout.close();
		// } catch (IOException e) {
		// System.out.println(e.getMessage());
		// }

		return ResponseEntity.ok().contentType(MediaType.parseMediaType(dbFile.getFileType()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dbFile.getFileName() + "\"")
				.body(new ByteArrayResource(dbFile.getData()));

	}

	/**
	 * gives the image by id
	 * 
	 * @param response
	 * @param fileId
	 * @throws Exception
	 * @author yash naik
	 */
	@GetMapping(path = "/getProductPhoto/{fileId}")
	public void getProductPhoto(HttpServletResponse response, @PathVariable("fileId") String fileId) throws Exception {
		response.setContentType("image/jpeg");

	}
}
