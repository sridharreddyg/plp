package com.capstore.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Customer;
import com.capstore.bean.Merchant;
import com.capstore.service.MerchantService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/merchant")
public class MerchantController {

	@Autowired
	private MerchantService service;

	/**
	 * Post mapping used for adding details in JSON format
	 * 
	 * @param merchant
	 * @return
	 */
	@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
	public Merchant saveMerchant(@RequestBody Merchant merchant) {
		service.saveMerchant(merchant);
		return merchant;

	}

	/**
	 * Fetching details by get Mapping
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping(path = "/{id}")
	public ResponseEntity<?> getMerchant(@PathVariable("id") int id) {
		try {
			Merchant merchant = service.findById(id);
			return new ResponseEntity<Merchant>(merchant, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>("Sorry. No Such Merchant Found", HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping(path = "/")
	public ResponseEntity<?> validateMerchant(@RequestParam("email") String email,
			@RequestParam("password") String password) {
		try {
			Merchant merchant = service.getByEmailAndPass(email, password);
			return new ResponseEntity<Merchant>(merchant, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>("Sorry. No Such Customer Found", HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Delete by deleteMapping by some specific id
	 * 
	 * @param id
	 */
	@DeleteMapping(path = "/{id}")
	public void deleteMerchant(@PathVariable("id") int id) {
		service.deleteMerchant(id);

	}

	@GetMapping(path = "/all")
	public ResponseEntity<?> getAllMerchant() {
		return new ResponseEntity<Iterable<Merchant>>(service.getAll(), HttpStatus.OK);
	}

	@PostMapping("/sendSmsInvitation/{mobNo}")
	public void sendSms(@PathVariable("mobNo") Long mobiles) {
		String authkey = "273915ApWohLj795cc1816f";
		// Multiple mobiles numbers separated by comma
		// Sender ID,While using route4 sender id should be 6 characters long.
		String senderId = "hgtyhg";
		// Your message to send, Add URL encoding here.
		String message = "Pleased to Join Our Capstore!!! link:www.capstore.com";
		// define route
		String route = "4";

		// Prepare Url
		URLConnection myURLConnection = null;
		URL myURL = null;
		BufferedReader reader = null;

		// encoding message
		String encoded_message = URLEncoder.encode(message);

		// Send SMS API
		String mainUrl = "http://api.msg91.com/api/sendhttp.php?";

		// Prepare parameter string
		StringBuilder sbPostData = new StringBuilder(mainUrl);
		sbPostData.append("authkey=" + authkey);
		sbPostData.append("&mobiles=" + mobiles);
		sbPostData.append("&message=" + encoded_message);
		sbPostData.append("&route=" + route);
		sbPostData.append("&sender=" + senderId);

		// final string
		mainUrl = sbPostData.toString();
		try {
			// prepare connection
			myURL = new URL(mainUrl);
			myURLConnection = myURL.openConnection();
			myURLConnection.connect();
			reader = new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
			// reading response
			String response;
			while ((response = reader.readLine()) != null)
				// print response
				System.out.println(response);

			// finally close connection
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
