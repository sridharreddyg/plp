package com.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Inventory;
import com.capstore.bean.Product;
import com.capstore.service.IInventoryService;
import com.capstore.service.IProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/inventory")
public class InventoryController {

	@Autowired
	IInventoryService service;

	/**
	 * @author Mayuresh Shinde create an inventory
	 */
	@PostMapping(path = "/{productId}/{merchantId}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Inventory> addInventory(@RequestBody Inventory inv, @PathVariable("productId") int productId,
			@PathVariable("merchantId") int merchantId) {
		return new ResponseEntity<Inventory>(service.addInventory(inv, productId, merchantId), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde update an inventory
	 */
	@PutMapping(path = "/{productId}/{merchantId}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Inventory> updateInventory(@RequestBody Inventory inv,
			@PathVariable("productId") int productId, @PathVariable("merchantId") int merchantId) {
		return new ResponseEntity<Inventory>(service.updateInventory(inv, productId, merchantId), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde delete an inventory
	 */
	@DeleteMapping(path = "/{invId}")
	public ResponseEntity<String> deleteInventory(@PathVariable int invId) {
		try {
			return new ResponseEntity<String>(service.deleteInventory(invId), HttpStatus.OK);
		} catch (EmptyResultDataAccessException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * @author Mayuresh Shinde
	 * @return all inventories(for admin)
	 */
	@GetMapping(path = "/all", produces = "application/json")
	public ResponseEntity<Iterable<Inventory>> getAllInventries() {
		return new ResponseEntity<Iterable<Inventory>>(service.getAllInventries(), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde
	 * @return all inventories of specific merchant
	 */
	@GetMapping(path = "/merchant/{merchantId}", produces = "application/json")
	public ResponseEntity<Iterable<Inventory>> inventriesOfMerchant(@PathVariable("merchantId") int merchantId) {
		return new ResponseEntity<Iterable<Inventory>>(service.inventriesOfMerchant(merchantId), HttpStatus.OK);
	}
}
