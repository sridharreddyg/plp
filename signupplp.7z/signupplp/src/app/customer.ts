
export class Customer{
    customerId:number;
    firstName:string;
    lastName:string;
    emailId:string;
    mobileNumber:string;
    Address:string;
    password:string;

}