import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { ActivatedRoute, Router } from '@angular/router';
import { SignupService } from '../signup.service';
import { Address } from '../address';
@Component({
  selector: 'app-new-customer',
  templateUrl: './new-customer.component.html',
  styleUrls: ['./new-customer.component.css']
})
export class NewCustomerComponent {

  customer:Customer;

  constructor(private route: ActivatedRoute, private router: Router, private userService: SignupService) {
    this.customer = new Customer();

  }

  onSubmit(customer:Customer) {
    
    this.userService.saveCustomer(this.customer)
  }
}


