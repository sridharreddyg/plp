import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SignupService {
private url:string;
  constructor(private httpmethod:HttpClient) {
   }
   public saveCustomer(customer:Customer){
     this.url='http://localhost:8615/capstore/api/v1/createcustomers';
     return this.httpmethod.post<Customer>(this.url,customer);
   }
}
