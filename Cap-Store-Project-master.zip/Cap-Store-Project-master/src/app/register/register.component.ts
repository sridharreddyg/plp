import { ServiceService } from '../services/service.service';
import { Registration } from './../models/registration';
import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import * as sha1 from 'sha1/sha1';
import * as moment from 'moment';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registration: Registration;
  passwordMatchError = false;
  conversionEncryptOutput: string;
  myForm: FormGroup;
  selectedDate;
  formattedDate;
  // form controls
  email = new FormControl('', [Validators.required, Validators.email]);
  passwordControl = new FormControl('', [
    Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]);
  repeatPasswordControl = new FormControl('', []);

  constructor(private service: ServiceService) {
    this.registration = new Registration();
    this.registration.gender = 'Male';
  }

  ngOnInit() {}
  getErrorMessage() {
    return this.email.hasError('required')
      ? 'Email is required'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  // validate password and confirm password
  validateboth() {
    if (this.registration.password !== '') {
      if (this.registration.password === this.registration.repeatpassword) {
        // password matches
      } else {
        this.repeatPasswordControl.setErrors(Validators.requiredTrue);
      }
    }
  }
  register() {
    const momentDate = new Date(this.selectedDate);
    this.formattedDate = moment(momentDate).format('DD/MM/YYYY');
    this.registration.dateofbirth = this.formattedDate;
    this.conversionEncryptOutput = sha1(this.registration.password);
    this.registration.password = this.conversionEncryptOutput;
    this.registration.repeatpassword = this.conversionEncryptOutput;
    this.service.registerDetails(this.registration).subscribe(
        result => {
          console.log(result);
        },
        error => {
          console.log(error);
        }
      );
  }
}
