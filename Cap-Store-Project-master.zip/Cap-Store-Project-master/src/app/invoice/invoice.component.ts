import { CheckoutService } from './../services/checkout.service';
import { Component, OnInit } from '@angular/core';
import { Order } from '../models/OrderModel';
import { Customer } from '../models/customerpage';
import { Product } from '../models/Product';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {

  ngxQrcode2 = 'https://material.angular.io/components/snack-bar/overview';
  invoiceArr:Order[]=[]
  products:Product[]=[]
  totalAmount:number=0
  customer:Customer = JSON.parse(localStorage.getItem("user"));

  constructor(private service:CheckoutService) { }

  ngOnInit() {
   this.fetchOrder();
  }

  fetchOrder()
  {
    this.service.getOrders().subscribe(
      res=>{
        console.log(res)
        this.invoiceArr = res;
      },err=>{console.log(err)},()=>{this.fetchProducts()}
  )
  }

  fetchProducts()
  {
    this.service.getProductsOrder().subscribe(
      res=>{
        console.log(res)
        this.products = res
        this.products.forEach(e=>{
          this.totalAmount = this.totalAmount + e.inventoryFromProduct[0].price;
        })
      },err=>{
        console.log(err)
      }
    )
  }
}
