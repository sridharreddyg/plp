import { ProductService } from './../services/product.service';
import { Component, OnInit, Input } from '@angular/core';
import { FeedBackModal } from '../models/feedbackModal';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  showReviewForm: boolean = false;
  newFeedback: FeedBackModal = new FeedBackModal();
  showReviews: FeedBackModal[] = [];

  @Input() id: number = 0;
  constructor(private productService: ProductService) { }

  ngOnInit() {
    console.log(this.id);
    this.fetchAllReviews();
  }

  fetchAllReviews() {
    this.productService.getReviewsById(this.id).subscribe(
      res => {
        this.showReviews = res
      }, err => { console.log(err) }
    )
  }
 
  addReview()
  {
    this.productService.postReviewById(this.newFeedback,this.id).subscribe(
      res=>{
        this.fetchAllReviews();
        this.showReviewForm = false;
      },err=>{console.log(err)}
    )
  }
}
