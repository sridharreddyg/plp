//  Author: Priyanka More

import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, EmailValidator } from '@angular/forms';
import { Router } from '@angular/router';
import { PasswordService } from '../services/password.service';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  // Email validation logic.
  inputEmail: string;

  getErrorMessage() {
    return this.email.hasError('required') ? 'Email is required' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }
  constructor(private router: Router, private passwordService: PasswordService) {
  }
  ngOnInit() {
  }

  // email will send to db where db in turn sends forgot password link to
  // mail where new password component will be loaded
  validate() {
    // Navigation path
    this.passwordService.validateEmail(this.inputEmail).subscribe(
      result => {
        console.log(result)
      },
      error => {
        console.log(error);
      }
    );
    // this.router.navigate(['/changepassword']);
    alert('Verfication mail is sent to you mail');
  }
}
