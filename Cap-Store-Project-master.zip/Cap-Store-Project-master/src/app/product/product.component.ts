import { CartService } from './../services/cart.service';
import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../models/Product';
import { FeedBackModal } from '../models/feedbackModal';
import { Merchant } from '../models/MerchantModel';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  selectedIndex:number=0;
  totalImg:String[]=["assets/test1.jpg","assets/test2.jpg","assets/test3.jpg"]
  colorIndex:boolean[]=[]

  similarProduct: String[] = ["assets/test1.jpg", "assets/test2.jpg", "assets/test3.jpg", "assets/test3.jpg", "assets/test1.jpg",
  "assets/test2.jpg", "assets/test3.jpg", "assets/test2.jpg", "assets/test1.jpg", "assets/test2.jpg"]
  
  productData:Product = new Product()
  similarProducts:Product[]=[];
  actualPrice:number=0;
  discount:number=0;
  showReviewForm: boolean = false;
  newFeedback: FeedBackModal = new FeedBackModal();
  showReviews: FeedBackModal[] = [];
  merchantRatings:number=0;
  merchants:Merchant[]=[]

  constructor(private productService:ProductService, 
    private route: ActivatedRoute,
    private router:Router,
    private cartService:CartService,
    public service:ServiceService
    ) { 
    this.colorIndex[0]=true;
  }

  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.productService.getProductById(id).subscribe(
      res=>{
        console.log(res);
        this.productData = res;
        this.actualPrice = this.productData.inventoryFromProduct["0"]["price"];
      this.discount = Math.floor((2000/this.actualPrice) *100);
      },
      err=>{console.log(err);this.router.navigate(['/'])},()=>{this.fetchAllReviews()}
    )
  }


  fetchSimilarProducts()
  {
    this.productService.getSimilarProducts(this.productData.id).subscribe(
      res=>{
        this.similarProducts = res;
        console.log(res)
      },err=>{console.log(err)
      },()=>{this.fetchMerchants()}
      )
  }

  fetchMerchants()
  {
    this.productService.getMerchants(this.productData.id).subscribe(
      res=>{console.log(res)
        this.merchants = res;
      },err=>{console.log(err)}
    )
  }
  currentImg(index)
  {
    this.colorIndex=[]
    this.colorIndex[index]=true
    this.selectedIndex = index;
  }

  fetchAllReviews() {
    this.productService.getReviewsById(this.productData.id).subscribe(
      res => {
        this.showReviews = res
        this.avg();
      }, err => { console.log(err) },()=>{this.fetchSimilarProducts()}
    )
  }

  avg()
  {
    var count = 0;
    this.showReviews.forEach(e=>{
      count = count + Number(e.productRating);
    })
    this.merchantRatings = Math.floor(count/this.showReviews.length);
  }
 
  addReview()
  {
    this.productService.postReviewById(this.newFeedback,this.productData.id).subscribe(
      res=>{
        this.fetchAllReviews();
        this.showReviewForm = false;
      },err=>{console.log(err)}
    )
  }

  addToCart()
  {
    var customerId = JSON.parse(localStorage.getItem("user"))["id"];
    this.cartService.postCart(customerId,this.productData.id).subscribe(
      res=>{console.log(res)},err=>{console.log(err)}
    )
  }

  addToWishlist()
  {
    this.cartService.postWishlist(this.productData.id).subscribe(
      res=>{console.log(res)},err=>{console.log(err)}
    )
  }
}
