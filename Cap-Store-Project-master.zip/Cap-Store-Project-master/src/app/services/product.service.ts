import { FeedBackModal } from './../models/feedbackModal';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/Product';
import { Merchant } from '../models/MerchantModel';
import { Category } from '../models/Category';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  baseHref = 'http://localhost:8888';
  constructor(private http: HttpClient) { }

  getAllProducts() {
    return this.http.get<Product[]>(this.baseHref + "/product/all")
  }

  getProductById(id: number) {
    return this.http.get<Product>(this.baseHref + "/product/get/" + id);
  }

  getMerchants(productId: number) {
    return this.http.get<Merchant[]>(this.baseHref + "/product/getmerchant/" + productId);
  }
  getAllCategory() {
    return this.http.get<Category[]>(this.baseHref + "/product/categories")
  }

  getCategoryById(id: number) {
    return this.http.get<Product>(this.baseHref + "/product/getcat/" + id);
  }

  getReviewsById(id: number) {
    return this.http.get<FeedBackModal[]>(this.baseHref + "/review/get/" + id);
  }

  postReviewById(review: FeedBackModal, id: number) {
    var body = {
      customerFirstName: review.customerFirstName,
      productComment: review.productComment,
      productRating: review.productRating
    }
    return this.http.post(this.baseHref + "/review/add/" + id, body);
  }

  getSimilarProducts(id: number) {
    return this.http.get<Product[]>(this.baseHref + "/product/getbyname/" + id);
  }

  searchResult(queryString: String) {
    return this.http.get<Product[]>(this.baseHref + '/product/getproduct/?queryString=' + queryString);
  }

  categorySearch(id:number)
  {
    return this.http.get<Category>(this.baseHref+"/product/getcat/"+id);
  }

}
