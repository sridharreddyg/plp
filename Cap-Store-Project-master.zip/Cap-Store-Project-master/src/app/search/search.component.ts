import { Product } from './../models/Product';
import { ProductService } from './../services/product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  
  product = new Product();
  productArr: Product[] = [];
  queryString: String;
  resultTrue = false;

  constructor(private productService:ProductService) { }
  ngOnInit() {
  }

  getAll() {
    this.productService.searchResult(this.queryString).subscribe(
      result => {
        this.productArr = result;
        this.resultTrue = true;
       }
    );
  }
}
