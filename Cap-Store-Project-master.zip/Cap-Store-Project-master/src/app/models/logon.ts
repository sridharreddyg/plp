export class Logon {

  email: string;
  password: string;
  conversionEncryptOutput: string;
  inputEmail: string;
}
