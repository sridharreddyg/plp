import { Logon } from './model/logon';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Registration } from './model/registration';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  logon = new Logon();
  constructor(private http: HttpClient) {
  }
  baseHref = 'http://localhost:8880';



  postOne(logon: Logon) {
    return this.http.post<Logon>(this.baseHref + '/add', logon);
  }
  registerDetails(register: Registration) {
    return this.http.post<Logon>(this.baseHref + '/register', register);
  }
}
