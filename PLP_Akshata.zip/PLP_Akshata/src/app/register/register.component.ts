import { ServiceService } from './../service.service';
import { Registration } from "./../model/registration";
import { Component, OnInit, Input } from "@angular/core";
import { FormControl, Validators } from "@angular/forms";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registration: Registration;
  @Input() isEditing: boolean;

  constructor(private service: ServiceService) {
    this.registration = new Registration();
  }

  email = new FormControl("", [Validators.required, Validators.email]);

  ngOnInit() {}
  getErrorMessage() {
    return this.email.hasError('required')
      ? 'You must enter a value'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  validateboth() {
    if (this.registration.password === this.registration.repeatpassword) {
      alert('Password match');

    } else {
      alert('Password do not match');
      this.registration.password = '';
      this.registration.repeatpassword ='';
    }
  }
  register() {
      this.service.registerDetails(this.registration).subscribe(
        result => {
          console.log(result);
          console.log("Registered Successfully");
        },
        error => {
          console.log(error);
        }
      );
  }
}
