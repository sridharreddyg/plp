export class Registration {
  firstname: String;
  lastname: String;
  address: String;
  email: String;
  password: String;
  repeatpassword: String;
  gender: String;
  dateofbirth: String;
}
