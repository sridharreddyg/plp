export class Logon {

  email: String;
  password: String;
  conversionEncryptOutput: string;
  inputEmail: String;
}
