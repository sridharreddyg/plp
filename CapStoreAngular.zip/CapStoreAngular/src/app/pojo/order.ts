import { Customer } from "./customer";


export class ProductOrder{

    orderId:number;
    customer: Customer;
    cart:any;
    orderDate:string;
    
    
    }