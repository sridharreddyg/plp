export class Coupon{
    couponId:number;
    couponImageUrl:string;
    maxDiscount:number;
    couponCode:string;
    discountPercentage:number;
    endDate:string;
}