
export class Card
{
    cardNumber:string;
	cardHolderName:string;
	expiryDate:Date;
	CVV:number;
    Balance:LongRange;
    pinNumber:number;
	
}