

export class Promo{
    promoId:number;
    promoCode:string;
    discount:number;
    endDate: string;
    }