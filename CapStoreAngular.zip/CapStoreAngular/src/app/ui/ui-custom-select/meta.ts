export interface UiCustomSelectOption {
  label: string;
  value: any;
}
