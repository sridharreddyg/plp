import { Component, OnInit } from '@angular/core';
import { ProductModel } from './product.model';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'CapStore';
  product = new ProductModel();
  productArr: ProductModel[] = [];

  constructor(private service: ApiService) { }

  ngOnInit() {
    this.getAll()
  }

  getAll() {
    this.service.getAll().subscribe(
      result => { this.productArr = result; },
      error => { console.log(error) }
    )
  }
  addOneProduct() {
    this.product.name = "Apple"
    this.product.price = 467.58

    this.service.postOne(this.product).subscribe(
      result => {
        console.log(result)
        console.log("Added Successfully")
      }, error => { console.log(error) }
    )
  }

  getOneProduct() {
    this.service.getOne(this.productArr[0].id).subscribe(
      result => {
        console.log(result)
      }, error => { console.log(error) }
    )
  }

  updateProduct() {
    this.product = this.productArr[0];
    this.product.name = "updatedName"

    this.service.putOne(this.product).subscribe(
      result => {
        console.log(result)
      }, error => { console.log(error) }
    )
  }

  deleteProduct() {
    this.service.deleteOne(this.productArr[0].id).subscribe(
      res => {
        console.log("Deleted succesfully")
      }, error => { console.log(error) }
    )
  }
}
