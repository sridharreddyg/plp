import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductModel } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  baseHref = "http://localhost:8880";

  getAll() {
    return this.http.get<ProductModel[]>(this.baseHref + "/all");
  }

  getOne(id: number) {
    return this.http.get<ProductModel>(this.baseHref + "/product/" + id);
  }

  postOne(product: ProductModel) {
    var body = {
      name: product.name,
      price: product.price
    }
    return this.http.post<ProductModel>(this.baseHref + "/add", body);
  }

  putOne(product: ProductModel) {
    return this.http.put<ProductModel>(this.baseHref + "/update", product);
  }

  deleteOne(id: number) {
    return this.http.delete(this.baseHref + "/delete/" + id);
  }
}
