package com.cg.rest;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;

import com.cg.entity.Product;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class HelloController {

	@Autowired
	private Rest rest;
	
	@GetMapping(path = "/all")
	public Iterable<Product> getAll() {
		Iterable<Product> p = rest.findAll();
		return p;
	}

	@GetMapping(path = "/product/{id}")
	public ResponseEntity<Product> get(@PathVariable("id") int id) {
		try {
			Optional<Product> result = rest.findById(id);
			Product p = result.get();
			return new ResponseEntity<Product>(p,HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("Sorry. No Product Found",HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
	public Product add(@RequestBody Product p) {
		rest.save(p);
		return p;
	}

	@PutMapping(path = "/update", consumes = "application/json")
	public Product edit(@RequestBody Product p) {
		rest.save(p);
		return p;
	}

	@DeleteMapping(path = "/delete/{id}")
	public void del(@PathVariable("id") int id) {
		rest.deleteById(id);
	}
}
