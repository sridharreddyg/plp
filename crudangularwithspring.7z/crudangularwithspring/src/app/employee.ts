export class Employee{
    empId:Number;
    empName:String;
    empSalary:number;
    empDepartment:string;

}