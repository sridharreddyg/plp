import { ServiceService } from "./../service.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FormControl, Validators } from "@angular/forms";
import * as sha1 from 'sha1/sha1';

import * as CryptoJS from "crypto-js";
import { Logon } from "../model/logon";

@Component({
  selector: "app-logon",
  templateUrl: "./logon.component.html",
  styleUrls: ["./logon.component.css"]
})
export class LogonComponent implements OnInit {
  inputEmail: string;

  conversionEncryptOutput: string;

  logon = new Logon();

  constructor(private service: ServiceService, private router: Router) {}
  hide = true;
  email = new FormControl("", [Validators.required, Validators.email]);

  ngOnInit() {}
  getErrorMessage() {
    return this.email.hasError("required")
      ? "You must enter a value"
      : this.email.hasError("email")
      ? "Not a valid email"
      : "";
  }
  login() {
    console.log("login");
  }

  encryptPassword() {
    /*this.conversionEncryptOutput = CryptoJS.AES.encrypt(
      this.logon.password.trim(),
      this.logon.email.trim()
    ).toString();*/
    this.conversionEncryptOutput = sha1(this.logon.password);
    this.logon.password = this.conversionEncryptOutput;

    this.router.navigate(["/"]);
  }

  addOneUser() {
    this.service.postOne(this.logon).subscribe(
      result => {
        console.log(result);
        console.log("Added Successfully");
      },
      error => {
        console.log(error);
      }
    );
  }
}
