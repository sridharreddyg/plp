import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { editcustomer } from '../model/editcustomer';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})

export class EditCustomerComponent implements OnInit {
  editcustomer: editcustomer;


  constructor(private service: ServiceService) {
    this.editcustomer = new editcustomer();
  }


  email = new FormControl("", [Validators.required, Validators.email]);
  inputEmail: string;


  ngOnInit() {
  }

  getErrorMessage() {
    return this.email.hasError('required')
      ? 'You must enter a value'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
  validateboth() {
    if (this.editcustomer.password === this.editcustomer.repeatpassword) {
      alert('Password match');

    } else {
      alert('Password do not match');
      this.editcustomer.password = '';
      this.editcustomer.repeatpassword ='';
    }
  }
  storeDetails() {
    this.service.storeDetails(this.editcustomer);
  }
}
