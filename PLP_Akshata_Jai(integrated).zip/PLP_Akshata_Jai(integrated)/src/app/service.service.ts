import { Logon } from './model/logon';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Registration } from './model/registration';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  logon = new Logon();
  receivedObj: Registration;
  constructor(private http: HttpClient,private routes: Router) {
  }
  baseHref = 'http://localhost:8880';



  postOne(logon: Logon) {
    return this.http.post<Logon>(this.baseHref + '/add', logon);
  }
  registerDetails(register: Registration) {
    return this.http.post<Logon>(this.baseHref + '/register', register);
  }
  storeDetails(obj: Registration): any {
    this.receivedObj = obj;
  }
  getCustomerDetails() {
    return this.receivedObj;
  }

}
