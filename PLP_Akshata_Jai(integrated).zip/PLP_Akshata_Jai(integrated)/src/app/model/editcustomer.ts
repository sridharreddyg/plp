export class editcustomer {
    
    customerId: number; 
    firstname: String;
    lastname: String;
    address: String;
    email: String;
    gender: String;
    dateofbirth: String;
    password: String;
    repeatpassword: String;
   
  }