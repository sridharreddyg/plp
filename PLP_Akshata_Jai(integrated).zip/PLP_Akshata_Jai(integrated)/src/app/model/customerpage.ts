export class customer {
    
    customerId: number; 
    firstname: String;
    lastname: String;
    address: String;
    email: String;
    gender: String;
    dateofbirth: String;
   
  }